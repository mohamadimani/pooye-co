# Wordpress Base Plugin

Base Plugin For Wordpress to Develop Any Plugin

 