<?php
/**
 * @package  WordpressBasePlugin
 */
require_once WordpressBasePlugin_DIR . '/methods/function.php';
require_once WordpressBasePlugin_DIR . '/methods/shortcodes.php';
require_once WordpressBasePlugin_DIR . '/methods/custompost.php';